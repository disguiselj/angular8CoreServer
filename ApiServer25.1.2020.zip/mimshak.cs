﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myfirstApi
{
    public class mimshak
    {
        public long N_mimshak { get; set; }
        public short k_sug_mimshak { get; set; }
        public string t_mimshak { get; set; }
        public string shem_file_yotze { get; set; }
        public short k_stts_klita { get; set; }
        public string correlationId { get; set; }
        public string shem_file_nichnas { get; set; }
        public string tshuva { get; set; }
        public string t_klita_tshuva { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace myfirstApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class NewWeatherController : ControllerBase
    {
        private string SqlConTEST = @"Application Name=just for fun;Password=rg1234;Persist Security Info=True;User ID=user1;Initial Catalog=justforfun;Data Source=DISGUISE-LAPTOP";
        // GET: api/NewWeather
        [HttpGet]
        public ActionResult<WeatherForecast[]> get()
        {
            return Ok(getDataFromDataBase(2));
            // return Ok(new NewWeather[] { new NewWeather { oneLine = "a", secondLine = "b" } });
        }


        private mimshak[] getDataFromDataBase(int numberofRows)
        {
            mimshak[] fullArr;
            using (SqlConnection connection = new SqlConnection(SqlConTEST))
            {
                connection.Open();

                string howManyRows = numberofRows.ToString();
                string sqlString = "select top " + howManyRows + " " +
                                    " n_mimshak,k_sug_mimshak,convert(varchar(10) , t_mimshak , 103 ) t_mimshak,shem_file_yotze," +
                                    " k_stts_klita,correlationId,shem_file_nichnas,tshuva,convert(varchar(10) , t_klita_tshuva , 103 ) t_klita_tshuva" +
                                    "  from tks_mimshak";

                using (SqlCommand command = new SqlCommand(
                    sqlString,
                    connection))
                {

                    fullArr = new mimshak[int.Parse(howManyRows)];
                    int i = 0;


                    using (SqlDataReader reader = command.ExecuteReader())
                    {


                        while (reader.Read())
                        {

                            fullArr[i] = new mimshak
                            {

                                N_mimshak = (long)reader["n_mimshak"],
                                k_sug_mimshak = (short)reader["k_sug_mimshak"],
                                t_mimshak = (string)reader["t_mimshak"],
                                shem_file_yotze = (string)reader["shem_file_yotze"],
                                k_stts_klita = (short)reader["k_stts_klita"],
                                correlationId = (string)reader["correlationId"],
                                shem_file_nichnas = (string)reader["shem_file_nichnas"],
                                tshuva = (string)reader["tshuva"],
                                t_klita_tshuva = (string)reader["t_klita_tshuva"]
                            };



                            i++;
                            if (i > 10000000)
                            {
                                break;
                            }
                            // reader.NextResult();

                        }

                    }
                }
            }

            if (fullArr is null)
            {
                return new mimshak[] { new mimshak { N_mimshak = -1, tshuva = "none" } };
            }
            else
            {
                return fullArr;
            }

         
        }

        // GET: api/NewWeather/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/NewWeather
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/NewWeather/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MimshakListComponent } from './mimshak-list.component';

describe('MimshakListComponent', () => {
  let component: MimshakListComponent;
  let fixture: ComponentFixture<MimshakListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MimshakListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MimshakListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mimshak-list',
  templateUrl: './mimshak-list.component.html',
  styleUrls: ['./mimshak-list.component.scss']
})
export class MimshakListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { TestBed } from '@angular/core/testing';

import { MimshakService } from './mimshak.service';

describe('MimshakService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MimshakService = TestBed.get(MimshakService);
    expect(service).toBeTruthy();
  });
});

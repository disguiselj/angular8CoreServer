import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MimshakRootComponent } from './mimshak-root.component';

describe('MimshakRootComponent', () => {
  let component: MimshakRootComponent;
  let fixture: ComponentFixture<MimshakRootComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MimshakRootComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MimshakRootComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mimshak-root',
  templateUrl: './mimshak-root.component.html',
  styleUrls: ['./mimshak-root.component.scss']
})
export class MimshakRootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

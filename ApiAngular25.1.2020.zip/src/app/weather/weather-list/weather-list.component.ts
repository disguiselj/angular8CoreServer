import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Weather } from '../../models/weather.model';


@Component({
  selector: 'app-weather-list',
  templateUrl: './weather-list.component.html',
  styleUrls: ['./weather-list.component.scss']
})
export class WeatherListComponent implements OnInit {

  constructor() { }
  @Input() listOfWeather: Weather[];
  @Output() oneWeather = new EventEmitter<Weather>();

  ngOnInit() {
  }

  clickme(w: Weather) {
    this.oneWeather.emit(w);
  }

}

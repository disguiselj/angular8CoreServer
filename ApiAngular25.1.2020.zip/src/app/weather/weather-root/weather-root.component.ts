import { Component, OnInit } from '@angular/core';
import { Weather } from '../../models/weather.model';
import { WeatherService } from '../weather.service';

@Component({
  selector: 'app-weather-root',
  templateUrl: './weather-root.component.html',
  styleUrls: ['./weather-root.component.scss']
})
export class WeatherRootComponent implements OnInit {

  constructor(private ws: WeatherService) { }

  listOfshowRoot: Weather[];

  ngOnInit() {
    // this.listOfshowRoot = [
    //   { Summary: 'one', TemperatureC: 1, TemperatureF: 11, datetime: 'date1' },
    //   { Summary: 'two', TemperatureC: 2, TemperatureF: 12, datetime: 'date2' },
    //   { Summary: 'three', TemperatureC: 3, TemperatureF: 13, datetime: 'date3' },
    //   { Summary: 'four', TemperatureC: 4, TemperatureF: 14, datetime: 'date4' },
    //   { Summary: 'five', TemperatureC: 5, TemperatureF: 15, datetime: 'date5' },
    //   { Summary: 'six', TemperatureC: 6, TemperatureF: 16, datetime: 'date6' }

    // ];

    this.ws.getTheWeather().subscribe(
      result => {
        this.listOfshowRoot = result;
        console.log('all done!');
        console.log(result.length);
        console.log(result);
      },
      error => { console.log(error); }

    );
  }

  TheWeatherWeChoose(w: Weather) {
    alert(w.temperatureF);
  }

}

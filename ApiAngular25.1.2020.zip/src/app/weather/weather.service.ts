import { Injectable } from '@angular/core';
import { observable, Observable } from 'rxjs';
import { Weather } from '../models/weather.model';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  constructor(private httpC: HttpClient) { }
  lotsOfweather: Weather[];



  getTheWeather(): Observable<Weather[]> {
    return this.httpC.get<Weather[]>('https://localhost:44393/weatherforecast');

  }


}

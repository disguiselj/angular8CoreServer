export interface Weather {
    temperatureC: number;
    temperatureF: number;
    summary: string;
}


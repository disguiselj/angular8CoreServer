import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WeatherRootComponent } from './weather/weather-root/weather-root.component';
import { WeatherListComponent } from './weather/weather-list/weather-list.component';
import { HttpClientModule } from '@angular/common/http';

import { MimshakRootComponent } from './mimshak/mimshak-root/mimshak-root.component';
import { MimshakListComponent } from './mimshak/mimshak-list/mimshak-list.component';

@NgModule({
  declarations: [
    AppComponent,
    WeatherRootComponent,
    WeatherListComponent,
    MimshakRootComponent,
    MimshakListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
